from app import db
import json
from collections import OrderedDict

class Base(db.Model):
    __abstract__=True

    id=db.Column(db.Integer(),primary_key=True)

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def toJson(self):
        return json.dumps(self.as_dict(),default=str)